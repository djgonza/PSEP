
public class Filosofo extends Thread {
	private int id;
	private Tenedor izda, dcha;

	public Filosofo(int id, Tenedor izda, Tenedor dcha) {
		this.id = id;
		this.izda = izda;
		this.dcha = dcha;
	}

	public synchronized void comer() throws InterruptedException {
		izda.coger(this.id);
		dcha.coger(this.id);
		System.out.println("El filosofo " + this.id + "esta comiendo");
		dcha.dejar(this.id);
		izda.dejar(this.id);

	}

	public synchronized void pensar() {

	}

	public void run() {
		while (true) {
			try {
				this.pensar();
				this.comer();

			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
