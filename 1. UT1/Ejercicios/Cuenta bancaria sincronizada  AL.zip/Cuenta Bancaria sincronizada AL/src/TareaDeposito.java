/**
 *  Una tarea que hace depósitos periódicos en la cuenta
 *  después de cada ingreso el hilo duerme TIEMPO
 */
class TareaDeposito  
{
    private CuentaBancaria cuenta;
    private double cantidad;

    private static final int INGRESOS = 10;  // nº ingresos que hace el hilo
    private static final int TIEMPO = 1000;  // tiempo que dormirá el hilo

    /**

     */
    public TareaDeposito(CuentaBancaria cuenta, double cantidad)
    {
         
    	
    	
    }

    public void run()
    {
 
    	
    	
    }

}

 