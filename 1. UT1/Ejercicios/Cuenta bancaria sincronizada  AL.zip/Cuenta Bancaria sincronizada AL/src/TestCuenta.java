import java.util.Random;
 

/**
   
   El programa ejecuta dos hilos que depositan dinero en la misma cuenta 
   bancaria
*/
public class TestCuenta 
{
   
   public static void main(String[] args)
   {
       
	   
	   
	   
        
   }
}

