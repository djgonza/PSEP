import java.util.ArrayList;
import java.util.List;

/**
 * 
 * Recurso compartido - Debe utilizarse en exclusi�n mutua. Los hilos
 * consumidores acceder�n a �l para tomar un elemento, el hilo productor para
 * a�adir un elemento
 * 
 */
public class Buffer
{
	private final int TAM = 10; // el tama�o m�ximo de la lista, el n� m�ximo de
	// elementos que se podr�n a�adir a ella
	private List<Integer> lista;

	public Buffer()
	{
		lista = new ArrayList<Integer>();
	}

	/**
	 * 
	 * a�adir un valor a la lista
	 * si la lista est� llena el productor  deber� esperar
	 * Despu�s de a�adir un valor se escribe el nombre del hilo y el valor a�adido
	 * y se avisa a los hilos que est�n esperando
	 */
	public     void insertar(int valor)
	{
		 
		
		
		
		
	}

	/**
	 * 
	 * borrar un valor de la lista (siempre el primero)
	 * si la lista est� vac�a el consumidor deber� esperar
	 * Despu�s de borrar un valor se escribe el nombre del hilo y el valor borrado
	 * y se avisa a los hilos que est�n esperando
	 */
	public    void borrar()
	{
		 
	}

}
